import './Choose.css'

const Choose =()=>{
    return(
        <div className='choose'>دسته بندی را انتخاب کنید
        <span className='arrow-two'>&#11206;</span>

        </div>
    )
}

export default Choose