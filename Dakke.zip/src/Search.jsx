import React from 'react'
import './Search.css'

const Search =()=>{
    return(
        <div className='Input'> 
                <input type='text' className='myInput' placeholder='برای جستجوی کالا اینجا بنویسید'></input>
        </div>


    )
}

export default Search;





    