const Button =()=>{
    return(
        <div className="Btn">
            <button className='myBtn btn btn-success'>پیدا کردن</button>

        </div>
    )
}

export default Button;