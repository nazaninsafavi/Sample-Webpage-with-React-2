import './Option.css'

const Option=()=>{
    return(
        <div className="btns">
             <button className='tools btn btn-light btn-lg'>املاک</button>
                <button className='tools btn btn-light btn-lg'> وسایل نقلیه</button>
                <button className='tools btn btn-light btn-lg'> استخدام و کاریابی</button>
                <button className='tools btn btn-light btn-lg'> کسب و کار تولیدی</button>
                <button className='tools btn btn-light btn-lg'> انسان دوستی و همیاری</button>
                <button className='tools btn btn-light btn-lg'> تفریح و سرگرمی</button>
                <button className='tools btn btn-light btn-lg'> لوازم شخصی</button>

        </div>

    )
}

export default Option;